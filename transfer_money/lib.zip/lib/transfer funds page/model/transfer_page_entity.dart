import 'package:clean_framework/clean_framework.dart';

class TransferPageEntity extends Entity{

  TransferPageEntity({this.id,this.accBal,this.accName,this.accType});
  final String id;
  final String accName;
  final double accBal;
  final String accType;
}

class TransferPageEntityList extends Entity{

  final List<TransferPageEntity> accDetails;
  final String selectedFromAccId;
  final String selectedToAccId;

  @override
  TransferPageEntityList(
      {List<EntityFailure> errors = const [],
        this.accDetails = const [],
        this.selectedFromAccId = '',
      this.selectedToAccId});

  @override
  TransferPageEntityList merge(
      {errors, List<TransferPageEntity> accDetails, String selectedFromAccId, String selectedToAccId}) {
    return TransferPageEntityList(
        errors: errors ?? this.errors,
        accDetails: accDetails ?? this.accDetails,
      selectedFromAccId: selectedFromAccId ?? this.selectedFromAccId,
        selectedToAccId: selectedToAccId ?? this.selectedToAccId);
  }
}