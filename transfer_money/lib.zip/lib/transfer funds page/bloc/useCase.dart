import 'package:clean_framework/clean_framework.dart';
import 'package:clean_framework/clean_framework_defaults.dart';
import 'package:transfer_money/core/example_locator.dart';
import 'package:transfer_money/transfer%20funds%20page/bloc/account_details_serviceAdapter.dart';
import 'package:transfer_money/transfer%20funds%20page/model/transfer_page_entity.dart';
import 'package:transfer_money/transfer%20funds%20page/model/transfer_page_viewModal.dart';

class TransferPageUseCase extends UseCase{
  Function(ViewModel) _accountDetailsViewModelCallBack;
  RepositoryScope scope;

  TransferPageUseCase({
    Function accountDetailsViewModelCallBack,
  }):  assert(accountDetailsViewModelCallBack != null),
        _accountDetailsViewModelCallBack = accountDetailsViewModelCallBack;

  void create() async {
    scope = ExampleLocator.instance.repository.containsScope<TransferPageEntityList>();
    if (scope == null)
      scope = ExampleLocator.instance.repository.create<TransferPageEntityList>(
          TransferPageEntityList(), _notifySubscribers,
          deleteIfExists: true);

    await ExampleLocator.instance.repository
        .runServiceAdapter(scope, AccountDetailsServiceAdapter());
  }
  void _notifySubscribers(entity) {
    _accountDetailsViewModelCallBack(buildViewModel(entity));
  }
  TransferPageViewModalList buildViewModel(TransferPageEntityList entity) {
    List<TransferPageViewModal> accDetails = [];
    entity.accDetails.forEach((e) {
      accDetails.add(TransferPageViewModal(id: e.id,
      accType: e.accType,
      accName: e.accName,
      accBal: e.accBal));
    });
    return TransferPageViewModalList(accDetails: accDetails);
  }
  int indexSelectedAlready(){

}
}