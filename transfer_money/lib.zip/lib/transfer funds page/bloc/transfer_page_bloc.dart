import 'package:clean_framework/clean_framework.dart';
import 'package:transfer_money/transfer%20funds%20page/api/account_details_service.dart';
import 'package:transfer_money/transfer%20funds%20page/bloc/useCase.dart';
import 'package:transfer_money/transfer%20funds%20page/model/transfer_page_viewModal.dart';

class TransferPageBloc extends Bloc{

  TransferPageUseCase _useCase;

  final Pipe<TransferPageFromAndToViewModal> selectedAccountDetails =
  Pipe<TransferPageFromAndToViewModal>();
  final Pipe<TransferPageViewModalList> accountDetails =
  Pipe<TransferPageViewModalList>(canSendDuplicateData: true);

  EventPipe setTheInitialStage = EventPipe();
  EventPipe getAccountDetails = EventPipe();

  TransferPageBloc({AccountDetailsService accountDetailsService}) {
    _useCase = TransferPageUseCase(accountDetailsViewModelCallBack: (viewModal){
      accountDetails.send(viewModal);
    });
    setTheInitialStage.listen(() {
     selectedAccountDetails.send(TransferPageFromAndToViewModal());
       });
    getAccountDetails.listen(() {
      _useCase.create();
    });
}

  @override
  void dispose() {
    selectedAccountDetails.dispose();
    accountDetails.dispose();
  }

}