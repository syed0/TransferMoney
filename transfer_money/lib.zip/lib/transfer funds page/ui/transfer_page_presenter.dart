import 'package:clean_framework/clean_framework.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:transfer_money/transfer%20funds%20page/bloc/transfer_page_bloc.dart';
import 'package:transfer_money/transfer%20funds%20page/model/transfer_page_viewModal.dart';
import 'package:transfer_money/transfer%20funds%20page/ui/transfer_page_screen.dart';

import 'account details/account_details_widget.dart';

class TransferPagePresenter extends Presenter<TransferPageBloc, TransferPageFromAndToViewModal, TransferPageScreen>{
  @override
  TransferPageScreen buildScreen(BuildContext context, TransferPageBloc bloc, TransferPageFromAndToViewModal viewModel) {
    return TransferPageScreen(context: context,viewModal: viewModel,onTap: (){
      Navigator.push(
          context,
          new MaterialPageRoute(
              builder: (context) => AccountDetailsWidget()));
    },);
  }

  @override
  Stream<TransferPageFromAndToViewModal> getViewModelStream(TransferPageBloc bloc) {
      return bloc.selectedAccountDetails.receive;
  }
  void sendViewModelRequest(TransferPageBloc bloc) {
    bloc.setTheInitialStage.launch();
  }


}