import 'package:clean_framework/clean_framework.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:transfer_money/transfer%20funds%20page/model/transfer_page_viewModal.dart';
import 'package:transfer_money/transfer%20funds%20page/ui/account%20details/account_details_widget.dart';

class TransferPageScreen extends Screen{

  final TransferPageFromAndToViewModal viewModal;
  final BuildContext context;
  final Function onTap;

  TransferPageScreen({this.context,this.viewModal,this.onTap});


  @override
  Widget build(BuildContext context) {


   return  Scaffold(
     appBar: AppBar(
       centerTitle: true,
       title: Text(
         'Transfer Funds',
         style: TextStyle(
           color: Colors.black,
           fontSize: 20,
         ),
       ),
     ),
     body: Column(
         children: [
           Column(crossAxisAlignment: CrossAxisAlignment.start,
               children: [
             Text("From", style: TextStyle(
               color: Colors.black,
               fontSize: 20,
             ),
             ),
              TextField(
                readOnly: true,
                       decoration:  InputDecoration(
                           hintText: viewModal.from == null?'Select the account': viewModal.from.accName, border: InputBorder.none),
                       textAlign: TextAlign.center,
                       onTap: (){
                        onTap();
                       },

                     ),
           ]),
           Column(
             crossAxisAlignment: CrossAxisAlignment.start,
             children: [
             Text("To", style: TextStyle(
               color: Colors.black,
               fontSize: 20,
             ),
             ),
               TextField(
                 readOnly: true,
                 decoration:  InputDecoration(
                     hintText: viewModal.to == null?'Select the account': viewModal.from.accName, border: InputBorder.none),
                 textAlign: TextAlign.center,
                 onTap: (){
                   onTap();
                 },

               ),
           ],),

         ],
       ),
   );

  }

}


