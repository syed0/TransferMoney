import 'package:clean_framework/clean_framework.dart';
import 'package:flutter/material.dart';
import 'package:transfer_money/transfer%20funds%20page/bloc/transfer_page_bloc.dart';

import 'account_details_presenter.dart';

class AccountDetailsWidget extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return  AccountDetailsPresenter();

  }

}