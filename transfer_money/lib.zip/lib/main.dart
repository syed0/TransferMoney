import 'package:clean_framework/clean_framework.dart';
import 'package:flutter/material.dart';
import 'package:transfer_money/landing%20page/landing_page_ui.dart';
import 'package:transfer_money/transfer%20funds%20page/bloc/transfer_page_bloc.dart';

void main() {
  runApp(MyHomePage());
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
// Provide a function to handle named routes.
// Use this function to identify the named
// route being pushed, and create the correct
// Screen.
      onGenerateRoute: (settings) {
// If you push the PassArguments route
        return MaterialPageRoute(
          builder: (context) {
            return BlocProvider<TransferPageBloc>(
              create :(_) => TransferPageBloc(),
              child : LandingPage(),
            ) ;
          },
        );
      },
    );
  }
}
